// background.js
chrome.action.onClicked.addListener((tab) => {
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['content.js']
    });
  });

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
if (request.action === "openNewTab") {
    // Use the Chrome API to create a new tab with the specified URL
    chrome.tabs.create({url: chrome.runtime.getURL('complete-page/index.html')});
}
});