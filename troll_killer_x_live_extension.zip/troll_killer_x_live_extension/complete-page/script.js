document.addEventListener("DOMContentLoaded", function () {
  document.querySelector("#currentTime").innerText =
    new Date().toLocaleString();

  document.getElementById("closeModal").addEventListener("click", function () {
    // window.close(); // Close the current tab
    document.querySelector("div.modal").style.display = "none";
  });

  document
    .getElementById("goToDashboard")
    .addEventListener("click", function () {
      window.location.href = "https://www.naver.com";
    });
});
