let isAppInitialized = false;

// DOM이 완전히 로드된 후 실행될 함수
function injectChatFilter() {
  // 채팅 필터 UI 컨테이너를 생성
  const chatFilterContainer = document.createElement("div");
  chatFilterContainer.id = "my-chat-filter";
  chatFilterContainer.style.width = "320px"; // 너비 설정
  chatFilterContainer.style.height = "100%"; // 높이 설정
  chatFilterContainer.style.position = "absolute"; // 고정 위치
  chatFilterContainer.style.top = "0"; // 상단에서의 위치
  chatFilterContainer.style.right = "0"; // 우측에서의 위치
  chatFilterContainer.style.backgroundColor = "#ddd"; // 배경색 설정
  chatFilterContainer.style.zIndex = "1000"; // z-index 설정
  chatFilterContainer.style.overflow = "auto"; // 스크롤 가능하도록 설정

  const reactAppDiv = document.createElement("div");
  reactAppDiv.id = "react-app-root";
  chatFilterContainer.appendChild(reactAppDiv);

  // 본문에 채팅 필터 UI 컨테이너 추가
  // document.body.appendChild(chatFilterContainer);

  // TODO: 필터링된 채팅 데이터를 로드하고 표시하는 로직을 추가

  // player-container 요소를 찾음
  const playerContainer = document.querySelector(
    "div#player-container-inner > #player-container"
  );

  // player-container가 존재하는 경우, 그 뒤에 새로운 div 삽입
  if (playerContainer) {
    playerContainer.insertAdjacentElement("afterend", chatFilterContainer);

    // 10초 뒤 아래 코드 실행
    setTimeout(() => {
      // 콘텐츠 스크립트에서
      chrome.runtime.sendMessage({ greeting: "hello" }, function (response) {
        console.log(response);
      });
    }, 2000);
  } else {
    // player-container를 찾을 수 없는 경우, 경고 또는 다른 처리를 수행
    console.warn("YouTube player container not found.");
  }

  if (!isAppInitialized) {
    const cssLink = document.createElement("link");
    cssLink.href = chrome.runtime.getURL("build/static/css/main.512aeccc.css"); // 예시 경로, 실제 경로로 변경 필요
    cssLink.type = "text/css";
    cssLink.rel = "stylesheet";
    document.head.appendChild(cssLink);

    // React 앱의 JS 파일 삽입
    const scriptTag = document.createElement("script");
    scriptTag.src = chrome.runtime.getURL("build/static/js/main.f7101eca.js"); // 예시 경로, 실제 경로로 변경 필요
    scriptTag.onload = function () {
      this.remove();
    };
    (document.head || document.documentElement).appendChild(scriptTag);
    isAppInitialized = true;
  }
}

// 새로운 동영상 페이지가 로드될 때마다 injectChatFilter 함수를 실행
// 주의: 유튜브는 SPA(Single Page Application)이므로, 페이지 전환 감지를 위한 추가적인 로직이 필요할 수 있음
// window.addEventListener("load", injectChatFilter);

// 유튜브 페이지 내비게이션 이벤트 감지를 위한 리스너 추가
// 유튜브는 AJAX를 통해 새로운 콘텐츠를 로드하므로, pushState와 같은 이벤트를 감지해야 함
window.addEventListener("yt-navigate-finish", injectChatFilter);
